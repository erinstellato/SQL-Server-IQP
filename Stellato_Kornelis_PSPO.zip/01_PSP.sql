/*============================================================================
  File:     01_PSP.sql

  SQL Server Versions: 2022 and earlier
------------------------------------------------------------------------------
  Written by Bob Ward, adapted by Erin Stellato
  original source: 
  https://github.com/microsoft/bobsql/tree/master/sql2022book/ch05_builtinqueryintelligence_getsbetter/pspopt
  
  (c) 2023 All rights reserved.

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Restore DB if needed
	Edit the locations for files to match your storage
*/
USE master;
GO
DROP DATABASE IF EXISTS WideWorldImporters;
GO
RESTORE DATABASE WideWorldImporters FROM DISK = 'C:\Backups\WideWorldImporters-Full.bak' WITH
	MOVE 'WWI_Primary' TO 'C:\Databases\SQL2022\WideWorldImporters\WideWorldImporters.mdf',
	MOVE 'WWI_UserData' TO 'C:\Databases\SQL2022\WideWorldImporters\WideWorldImporters_UserData.ndf',
	MOVE 'WWI_Log' TO 'C:\Databases\SQL2022\WideWorldImportersideWorldImporters.ldf',
	MOVE 'WWI_InMemory_Data_1' TO 'C:\Databases\SQL2022\WideWorldImporters\WideWorldImporters_InMemory_Data_1',
	stats=5;
GO

/*
	Create skew
*/
USE WideWorldImporters;
GO
DECLARE @StockItemID int;
DECLARE @StockItemName varchar(100);
DECLARE @SupplierID int;
SELECT @StockItemID = 228;
SET @StockItemName = 'Cleveland Browns Shirt'+convert(varchar(10), @StockItemID);
SET @SupplierID = 4;
DELETE FROM Warehouse.StockItems WHERE StockItemID >= @StockItemID;
SET NOCOUNT ON;
BEGIN TRANSACTION;
WHILE @StockItemID <= 4000000
BEGIN
INSERT INTO Warehouse.StockItems
(StockItemID, StockItemName, SupplierID, UnitPackageID, OuterPackageID, LeadTimeDays,
QuantityPerOuter, IsChillerStock, TaxRate, UnitPrice, TypicalWeightPerUnit, LastEditedBy
)
VALUES (@StockItemID, @StockItemName, @SupplierID, 10, 9, 12, 100, 0, 15.00, 100.00, 0.300, 1);
SET @StockItemID = @StockItemID + 1;
SET @StockItemName = 'Cleveland Browns Shirt'+convert(varchar(10), @StockItemID);
END;
COMMIT TRANSACTION;
SET NOCOUNT OFF;
GO
DECLARE @StockItemID int;
DECLARE @StockItemName varchar(100);
DECLARE @SupplierID int;
SELECT @StockItemID = 4000001;
SET @StockItemName = 'Cleveland Browns Mug'+convert(varchar(10), @StockItemID);
SET @SupplierID = 5;
DELETE FROM Warehouse.StockItems WHERE StockItemID >= @StockItemID;
SET NOCOUNT ON;
BEGIN TRANSACTION;
WHILE @StockItemID <= 8000000
BEGIN
INSERT INTO Warehouse.StockItems
(StockItemID, StockItemName, SupplierID, UnitPackageID, OuterPackageID, LeadTimeDays,
QuantityPerOuter, IsChillerStock, TaxRate, UnitPrice, TypicalWeightPerUnit, LastEditedBy
)
VALUES (@StockItemID, @StockItemName, @SupplierID, 10, 9, 12, 100, 0, 15.00, 100.00, 0.300, 1);
SET @StockItemID = @StockItemID + 1;
SET @StockItemName = 'Cleveland Browns Mug'+convert(varchar(10), @StockItemID);
END;
COMMIT TRANSACTION;
SET NOCOUNT OFF;
GO

/*
	Rebuild index
*/
USE WideWorldImporters;
GO
ALTER INDEX FK_Warehouse_StockItems_SupplierID ON Warehouse.StockItems REBUILD;
GO

/*
	Create procedure
*/
USE WideWorldImporters;
GO
CREATE OR ALTER PROCEDURE [Warehouse].[GetStockItemsbySupplier]  @SupplierID int
AS
BEGIN
SELECT StockItemID, SupplierID, StockItemName, TaxRate, LeadTimeDays
FROM Warehouse.StockItems s
WHERE SupplierID = @SupplierID
ORDER BY StockItemName;
END;
GO


/*
	pre-2022 configuration
*/
USE WideWorldImporters;
GO
ALTER DATABASE WideWorldImporters SET COMPATIBILITY_LEVEL = 150;
GO
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO
ALTER DATABASE WideWorldImporters SET QUERY_STORE CLEAR;
GO

/*
	This will generate an index seek
*/
USE WideWorldImporters;
GO
SET STATISTICS TIME ON;
GO
EXEC Warehouse.GetStockItemsbySupplier 2;
GO

/*
	View estimated plan (it will be index seek)
	I don't recommended trying to run this...
	You can also clear procedure cache and see that it generates a clustered index scan
*/
USE WideWorldImporters;
GO
EXEC Warehouse.GetStockItemsbySupplier 4;
GO

/*
	Clear cache, re-run
*/
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO

/*
	Look at skew
*/
USE WideWorldImporters;
GO
SELECT SupplierID, count(*) as SupplierCount
FROM Warehouse.StockItems
GROUP BY SupplierID;
GO

