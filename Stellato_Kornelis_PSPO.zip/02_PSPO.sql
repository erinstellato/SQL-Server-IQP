/*============================================================================
  File:     02_PSPO.sql

  SQL Server Versions: 2022 and earlier
------------------------------------------------------------------------------
  Written by Bob Ward, adapted by Erin Stellato
  original source: 
  https://github.com/microsoft/bobsql/tree/master/sql2022book/ch05_builtinqueryintelligence_getsbetter/pspopt
  
  (c) 2023 All rights reserved.

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Change to compat mode 160 to use PSPO
*/
USE WideWorldImporters;
GO
ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 160;
GO
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO
ALTER DATABASE CURRENT SET QUERY_STORE CLEAR;
GO

/*
	re-run queries
*/
/*
	This will generate an index seek
*/
USE WideWorldImporters;
GO
EXEC Warehouse.GetStockItemsbySupplier 2;
GO

/*
	This will generate an index scan
*/
USE WideWorldImporters;
GO
EXEC Warehouse.GetStockItemsbySupplier 4;
GO

/*
	What's in Query Store?
*/

/*
	This is the "parent" query
	Notice this is the SELECT statement from the procedure with no OPTION for variants.
*/
USE WideWorldImporters;
GO

SELECT *
FROM sys.query_store_query_variant

SELECT 
	qt.query_sql_text, 
	qt.query_text_id, 
	q.query_id, 
	q.object_id, 
	OBJECT_NAME(q.object_id),
	q.query_hash, 
	qv.query_variant_query_id, 
	qv.parent_query_id, 
	qv.dispatcher_plan_id, 
	p.plan_type,
	p.plan_type_desc,
	TRY_CAST(p.query_plan AS XML) AS xml_plan
FROM sys.query_store_query_text qt
JOIN sys.query_store_query q
	ON qt.query_text_id = q.query_text_id
JOIN sys.query_store_query_variant qv
	ON q.query_id = qv.parent_query_id
JOIN sys.query_store_plan p
	ON qv.dispatcher_plan_id = p.plan_id;
GO

/*
	Look at the queries and plans for variants
	Notice each query is from the same parent_query_id and the query_hash is the same
*/
USE WideWorldImporters;
GO
SELECT 
	qt.query_sql_text, 
	q.query_id, 
	q.object_id,
	qv.query_variant_query_id, 
	qv.parent_query_id, 
	q.query_hash,
	rs.count_executions, 
	qsp.plan_id, 
	qv.dispatcher_plan_id, 
	qsp.query_plan_hash,
	TRY_CAST(qsp.query_plan as XML) AS xml_plan
FROM sys.query_store_query_text qt
JOIN sys.query_store_query q
	ON qt.query_text_id = q.query_text_id
JOIN sys.query_store_plan qsp
	ON q.query_id = qsp.query_id
JOIN sys.query_store_query_variant qv
	ON q.query_id = qv.query_variant_query_id
JOIN sys.query_store_runtime_stats rs
	ON qsp.plan_id = rs.plan_id
ORDER BY qv.parent_query_id;
GO




